/* Fixed hyperparameters; all predictions precede outcome observation. */
const Advanced=(()=>{
'use strict';
const E=typeof module!=='undefined'&&module.exports?require('./engine.js'):Engine;
const {P,TRAIN,WARM,rng,rank,hit,choose,sigmoid}=E;
const keys=['ai','forest','neural','ensemble','freq','random'];
const models=keys.slice(0,4);
const names={ai:'로지스틱',forest:'랜덤 포레스트',neural:'신경망',ensemble:'앙상블',freq:'30회 빈도',random:'무작위'};
const nums=Array.from({length:45},(_,i)=>i+1),mean=a=>a.reduce((s,x)=>s+x,0)/a.length;
function neural(){
 const rand=rng(918172),H=8,D=7;let a=Array.from({length:H},()=>Array.from({length:D},()=>.12*(rand()-.5))),b=Array.from({length:H},()=>.12*(rand()-.5)),bias=Math.log(P/(1-P));
 function forward(f){const h=a.map(w=>Math.tanh(w.reduce((s,v,j)=>s+v*f[j],0)));return {h,p:sigmoid(bias+h.reduce((s,v,j)=>s+v*b[j],0))};}
 function learn(x,y){const da=a.map(w=>w.map(()=>0)),db=b.map(()=>0);let d0=0;for(let i=0;i<45;i++){const {h,p}=forward(x[i]),d=(p-y[i])/45;d0+=d;for(let k=0;k<H;k++){db[k]+=d*h[k];const dh=d*b[k]*(1-h[k]*h[k]);for(let j=0;j<D;j++)da[k][j]+=dh*x[i][j];}}
  bias-=.08*d0;for(let k=0;k<H;k++){b[k]-=.08*(db[k]+.01*b[k]);for(let j=0;j<D;j++)a[k][j]-=.08*(da[k][j]+.01*a[k][j]);}}
 return {predict:x=>x.map(f=>forward(f).p),learn};
}
// Small batch random forest: bootstrap samples, random feature subsets, impurity-selected splits.
function forest(){let history=[],trees=[],seen=0;const B=9,N=512,DEPTH=3;
 function makeTree(a,depth,rand){let pos=a.reduce((s,r)=>s+r.y,0),p=(pos+12*P)/(a.length+12),node={p};if(depth>=DEPTH||a.length<32||pos===0||pos===a.length)return node;
  let best=null,base=pos*(a.length-pos)/a.length;
  const fs=[1,2,3,4,5,6];for(let j=0;j<3;j++){let k=j+Math.floor(rand()*(fs.length-j));[fs[k],fs[j]]=[fs[j],fs[k]];const f=fs[j];for(let k=0;k<3;k++){let v=a[Math.floor(rand()*a.length)].x[f];let left=[],right=[],lp=0;for(const row of a){if(row.x[f]<=v){left.push(row);lp+=row.y;}else right.push(row);}if(left.length<12||right.length<12)continue;let rp=pos-lp,gain=base-lp*(left.length-lp)/left.length-rp*(right.length-rp)/right.length;if(gain>1e-9&&(!best||gain>best.gain))best={f,v,left,right,gain};}}
  if(best){node.f=best.f;node.v=best.v;node.l=makeTree(best.left,depth+1,rand);node.r=makeTree(best.right,depth+1,rand);}return node;}
 function predict(x){return x.map(f=>trees.length?mean(trees.map(t=>{while(t.l)t=f[t.f]<=t.v?t.l:t.r;return t.p;})):P);}
 function learn(x,y){history.push(x.map((f,i)=>({x:f,y:y[i]})));if(history.length>120)history.shift();seen++;
  if(seen===20||seen%25===0){const pool=history.flat(),rand=rng(0x87abc^seen);trees=Array.from({length:B},()=>makeTree(Array.from({length:N},()=>pool[Math.floor(rand()*pool.length)]),0,rand));}}
 return {predict,learn};}
function normalize(a){ // common probability scale, sum ~6, bounded 0..1
 let lo=0,hi=100;for(let i=0;i<28;i++){let m=(lo+hi)/2;if(a.reduce((s,v)=>s+Math.min(1,v*m),0)>6)hi=m;else lo=m;}return a.map(v=>Math.min(1,v*(lo+hi)/2));}
function normCdf(x){const z=Math.abs(x),t=1/(1+.2316419*z),d=.3989422804014327*Math.exp(-z*z/2),p=1-d*t*(.319381530+t*(-.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));return x>=0?p:1-p;}
const nullVar=6*P*(1-P)*(39/44),threeP=E.theory.slice(3).reduce((a,b)=>a+b,0);
function summarize(h){const n=h.reduce((s,v)=>s+v,0),avg=h.reduce((s,v,i)=>s+v*i,0)/n,three=h.slice(3).reduce((a,b)=>a+b,0),variance=n>1?h.reduce((s,v,i)=>s+v*(i-avg)**2,0)/(n-1):0,margin=1.96*Math.sqrt(variance/n),z=(avg-.8)/Math.sqrt(nullVar/n),p=Math.max(0,Math.min(1,2*(1-normCdf(Math.abs(z)))));return {avg,three,max:h.reduce((s,v,i)=>v?i:s,0),ci:[Math.max(0,avg-margin),Math.min(6,avg+margin)],p,adjusted:Math.min(1,p*keys.length)};}
function run(rows,limit=100){E.check(rows);if(!Number.isInteger(limit)||limit<1)throw Error('검증 기간 오류');const lr=E.create(),nn=neural(),rf=forest(),start=Math.max(WARM,rows.length-limit),hist=Object.fromEntries(keys.map(k=>[k,Array(7).fill(0)])),brier=Object.fromEntries(models.map(k=>[k,0])),evaluated=[];
 function probs(x){const a=lr.predict(x),f=normalize(rf.predict(x)),n=normalize(nn.predict(x));return {ai:a,forest:f,neural:n,ensemble:a.map((v,i)=>(v+f[i]+n[i])/3)};}
 for(let t=0;t<rows.length;t++){const row=rows[t],x=lr.features(),y=nums.map(n=>Number(row.n.includes(n)));if(t>=start){const p=probs(x),pred=Object.fromEntries(models.map(k=>[k,rank(p[k],row.round).slice(0,6).map(a=>a.n).sort((a,b)=>a-b)]));pred.freq=rank(lr.frequency(),row.round).slice(0,6).map(a=>a.n).sort((a,b)=>a-b);pred.random=E.randomTicket(rng((row.round^0x25AC43B7)>>>0));const h={};for(const k of keys){h[k]=hit(pred[k],row);hist[k][h[k]]++;}for(const k of models)brier[k]+=p[k].reduce((s,v,i)=>s+(v-y[i])**2,0)/45;evaluated.push({round:row.round,pred,h,actual:row.n.slice()});}
  if(t>=TRAIN){lr.learn(x,row.n);nn.learn(x,y);rf.learn(x,y);}lr.observe(row);}
 const count=evaluated.length,next=rows.at(-1).round+1,p=probs(lr.features());const scores=Object.fromEntries(models.map(k=>[k,rank(p[k],next)]));const summary=Object.fromEntries(keys.map(k=>[k,summarize(hist[k])]));for(const k of models)summary[k].brier=brier[k]/count;
 const blocks=[];for(let i=0;i<count;i+=100){const block=evaluated.slice(i,i+100);blocks.push({start:block[0].round,end:block.at(-1).round,n:block.length,avg:Object.fromEntries(keys.map(k=>[k,mean(block.map(r=>r.h[k]))]))});}
 return {count,start:evaluated[0].round,end:evaluated.at(-1).round,next,scores,summary,hist,evaluated,blocks,uniformBrier:P*(1-P),threeP};}
function patterns(rows){const pairs=new Map(),triples=new Map(),ends=Array(10).fill(0),low=Array(7).fill(0),sumBins=Array(9).fill(0),roll=Array(7).fill(0);let sameEnd=0,adj=0;
 const inc=(m,k)=>m.set(k,(m.get(k)||0)+1);
 for(let r=0;r<rows.length;r++){const a=rows[r].n;const ending=a.map(n=>n%10);for(const n of ending)ends[n]++;if(new Set(ending).size<6)sameEnd++;if(a.some((n,i)=>i&&n===a[i-1]+1))adj++;low[a.filter(n=>n<=22).length]++;sumBins[Math.min(8,Math.floor(a.reduce((s,n)=>s+n,0)/30))]++;if(r&&rows[r].round===rows[r-1].round+1)roll[hit(a,rows[r-1])]++;
  for(let i=0;i<6;i++)for(let j=i+1;j<6;j++){inc(pairs,`${a[i]},${a[j]}`);for(let k=j+1;k<6;k++)inc(triples,`${a[i]},${a[j]},${a[k]}`);}}
 const top=(m,k)=>{const expected=rows.length*choose(6,k)/choose(45,k);return [...m.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0],'en',{numeric:true})).slice(0,20).map(([key,count])=>({n:key.split(',').map(Number),count,expected,lift:count/expected}));};
 return {pairs:top(pairs,2),triples:top(triples,3),ends,low,sumBins,roll,sameEnd,adj,n:rows.length};}
function parseNums(s){s=String(s).trim();if(!s)return [];if(!/^\d+(?:[\s,]+\d+)*$/.test(s))throw Error('번호는 숫자와 쉼표 또는 공백으로 입력하세요.');const a=s.split(/[\s,]+/).map(Number);if(a.some(n=>!Number.isInteger(n)||n<1||n>45)||new Set(a).size!==a.length)throw Error('번호는 중복 없이 1~45로 입력하세요.');return a.sort((a,b)=>a-b);}
function generate(opts,rand=Math.random){let {fixed=[],exclude=[],odd=null,min=21,max=255,count=5}=opts;if(!Array.isArray(fixed)||!Array.isArray(exclude)||[...fixed,...exclude].some(n=>!nums.includes(n))||new Set(fixed).size!==fixed.length||new Set(exclude).size!==exclude.length||fixed.length>6||fixed.some(n=>exclude.includes(n)))throw Error('고정수·제외수 설정을 확인하세요.');if(!Number.isInteger(count)||count<1||count>20||!Number.isInteger(min)||!Number.isInteger(max)||min<21||max>255||min>max||!(odd===null||(Number.isInteger(odd)&&odd>=0&&odd<=6)))throw Error('홀수 개수, 합계 또는 게임 수 범위를 확인하세요.');const pool=nums.filter(n=>!fixed.includes(n)&&!exclude.includes(n)),need=6-fixed.length,base=fixed.reduce((a,b)=>a+b,0);if(pool.length<need)throw Error('남은 번호가 부족합니다.');if(base+pool.slice(0,need).reduce((a,b)=>a+b,0)>max||base+(need?pool.slice(-need):[]).reduce((a,b)=>a+b,0)<min)throw Error('지정한 합계를 만들 수 없습니다.');const fOdd=fixed.filter(n=>n%2).length;if(odd!==null&&(odd<fOdd||odd>fOdd+Math.min(need,pool.filter(n=>n%2).length)||6-odd<fixed.length-fOdd||6-odd>fixed.length-fOdd+Math.min(need,pool.filter(n=>!(n%2)).length)))throw Error('지정한 홀짝 조건을 만들 수 없습니다.');let tickets=[],seen=new Set(),tries=0;
 for(;tries<25000&&tickets.length<count;tries++){const a=pool.slice();for(let i=0;i<need;i++){const j=i+Math.floor(rand()*(a.length-i));[a[i],a[j]]=[a[j],a[i]];}const t=[...fixed,...a.slice(0,need)].sort((a,b)=>a-b),s=t.reduce((a,b)=>a+b,0),key=t.join(',');if(s<min||s>max||(odd!==null&&t.filter(n=>n%2).length!==odd)||seen.has(key))continue;seen.add(key);tickets.push(t);if(need===0)break;}
 return {tickets,tries,complete:tickets.length===count};}
function result(ticket,row){if(!row)return '추첨 결과 없음';const h=hit(ticket,row);if(h===6)return '1등';if(h===5)return row.bonus===null?'5개 일치 · 보너스 미확인':ticket.includes(row.bonus)?'2등':'3등';if(h===4)return '4등';if(h===3)return '5등';return `${h}개 일치`;}
function validateSaved(list){if(!Array.isArray(list)||list.length>500)throw Error('저장 조합은 최대 500개입니다.');const out=[],seen=new Set();for(const r of list){if(!r||!Number.isSafeInteger(r.round)||r.round<1||!Array.isArray(r.n)||r.n.length!==6||r.n.some(n=>!nums.includes(n))||new Set(r.n).size!==6||!['조건 조합','로지스틱','랜덤 포레스트','신경망','앙상블'].includes(r.kind))throw Error('저장 조합 형식 오류');const n=r.n.slice().sort((a,b)=>a-b),key=r.round+':'+n.join(',');if(!seen.has(key)){seen.add(key);out.push({round:r.round,n,kind:r.kind});}}return out;}
return {keys,models,names,run,patterns,parseNums,generate,result,validateSaved};})();
if(typeof module!=='undefined'&&module.exports)module.exports=Advanced;
