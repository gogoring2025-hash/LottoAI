const E=require('./engine.js'),assert=require('node:assert/strict');
// Synthetic fixtures only; these are NOT historical winning numbers.
const rand=E.rng(123), data=E.validate(Array.from({length:1251},(_,i)=>{const n=E.randomTicket(rand);return {round:i+1,n,bonus:Array.from({length:45},(_,j)=>j+1).find(x=>!n.includes(x))};}));
assert.deepEqual(E.parse(E.csv(data)),data);assert.deepEqual(E.parse(JSON.stringify({draws:data.map(d=>({draw:d.round,numbers:d.n,bonus:d.bonus}))})),data);
assert.deepEqual(E.parse('drwNo,drwNoDate,n1,n2,n3,n4,n5,n6,bonus,firstWinamnt\n1,2002-12-07,10,23,29,33,37,40,16,5'),[{round:1,n:[10,23,29,33,37,40],bonus:16}]);
assert.throws(()=>E.parse('1,1,1,2,3,4,5'));assert.throws(()=>E.parse('1,1,2,3,4,5,46'));assert.throws(()=>E.parse('1,1,2,3,4,5,6,6'));
assert.throws(()=>E.run(data.slice(0,79)));assert.throws(()=>E.run(data.filter(d=>d.round!==10)));assert.equal(E.verifyRemote(data.slice(-10),data).length,1251);assert.throws(()=>E.verifyRemote(data,data.slice(0,-1)));
assert.throws(()=>E.verifyRemote([{round:1,n:[1,2,3,4,5,6],bonus:7}],data));
const all=E.run(data,10000),recent=E.run(data,100);assert.equal(all.count,1201);assert.equal(recent.count,100);assert.equal(recent.start,1152);assert.equal(recent.next,1252);assert.equal(recent.scores.length,45);assert.ok(recent.scores.every(x=>x.score>=0&&x.score<=1));assert.deepEqual(all.evaluated.slice(-100),recent.evaluated);
for(const h of Object.values(all.hist))assert.equal(h.reduce((a,b)=>a+b,0),1201);assert.equal(E.theory.reduce((a,b)=>a+b,0),1);assert.ok(Math.abs(E.theory.reduce((a,p,i)=>a+i*p,0)-.8)<1e-12);assert.equal(E.theory[6],1/8145060);
// Anti-leakage: even changing the target round itself cannot change its prediction.
const prefix=data.slice(0,100),changed=prefix.map((d,i)=>i===99?{...d,n:E.randomTicket(E.rng(9))}:d);const a=E.run(prefix,1),b=E.run(changed,1);assert.deepEqual(a.evaluated[0].ai,b.evaluated[0].ai);assert.notDeepEqual(a.evaluated[0].actual,b.evaluated[0].actual);
assert.deepEqual(E.run(prefix,1).scores,E.run(prefix,1).scores);
assert.equal(E.stats(data).items.reduce((a,b)=>a+b.count,0),1251*6);
console.log('PASS: CSV/JSON, range/duplicates, gap detection, update integrity, 1,251 synthetic draws, repeatability, no target leakage, theoretical probabilities.');
