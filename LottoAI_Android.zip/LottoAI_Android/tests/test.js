const E=require('./engine.js'),assert=require('node:assert/strict');
// Synthetic fixtures only; these are NOT historical winning numbers.
const rand=E.rng(123), data=E.validate(Array.from({length:1251},(_,i)=>{const n=E.randomTicket(rand);return {round:i+1,n,bonus:Array.from({length:45},(_,j)=>j+1).find(x=>!n.includes(x))};}));
assert.deepEqual(E.parse(E.csv(data)),data);assert.deepEqual(E.parse(JSON.stringify({draws:data.map(d=>({draw:d.round,numbers:d.n,bonus:d.bonus}))})),data);
assert.deepEqual(E.parse('drwNo,drwNoDate,n1,n2,n3,n4,n5,n6,bonus,firstWinamnt\n1,2002-12-07,10,23,29,33,37,40,16,5'),[{round:1,n:[10,23,29,33,37,40],bonus:16}]);
assert.throws(()=>E.parse('1,1,1,2,3,4,5'));assert.throws(()=>E.parse('1,1,2,3,4,5,46'));assert.throws(()=>E.parse('1,1,2,3,4,5,6,6'));
assert.throws(()=>E.run(data.slice(0,79)));assert.throws(()=>E.run(data.filter(d=>d.round!==10)));assert.equal(E.verifyRemote(data.slice(-10),data).length,1251);assert.throws(()=>E.verifyRemote(data,data.slice(0,-1)));
assert.throws(()=>E.verifyRemote([{round:1,n:[1,2,3,4,5,6],bonus:7}],data));
const all=E.run(data,10000),recent=E.run(data,100);assert.equal(all.count,1201);assert.equal(recent.count,100);assert.equal(recent.start,1152);assert.equal(recent.next,1252);assert.equal(recent.scores.length,45);assert.ok(recent.scores.every(x=>x.score>=0&&x.score<=1));assert.deepEqual(all.evaluated.slice(-100),recent.evaluated);
for(const h of Object.values(all.hist))assert.equal(h.reduce((a,b)=>a+b,0),1201);assert.equal(E.theory.reduce((a,b)=>a+b,0),1);assert.ok(Math.abs(E.theory.reduce((a,p,i)=>a+i*p,0)-.8)<1e-12);assert.equal(E.theory[6],1/8145060);
// Anti-leakage: even changing the target round itself cannot change its prediction.
const prefix=data.slice(0,100),changed=prefix.map((d,i)=>i===99?{...d,n:E.randomTicket(E.rng(9))}:d);const a=E.run(prefix,1),b=E.run(changed,1);assert.deepEqual(a.evaluated[0].ai,b.evaluated[0].ai);assert.notDeepEqual(a.evaluated[0].actual,b.evaluated[0].actual);
assert.deepEqual(E.run(prefix,1).scores,E.run(prefix,1).scores);
assert.equal(E.stats(data).items.reduce((a,b)=>a+b.count,0),1251*6);
console.log('PASS: CSV/JSON, range/duplicates, gap detection, update integrity, 1,251 synthetic draws, repeatability, no target leakage, theoretical probabilities.');
const A=require('./advanced.js');
const v2=A.run(data,10000), tail=A.run(data,100);assert.equal(v2.count,1201);assert.equal(v2.start,51);assert.equal(v2.end,1251);assert.equal(tail.count,100);assert.deepEqual(v2.evaluated.slice(-100),tail.evaluated);assert.deepEqual(tail.scores,v2.scores);
for(const k of A.keys){assert.equal(v2.hist[k].reduce((a,b)=>a+b,0),1201);assert.ok(v2.summary[k].p>=0&&v2.summary[k].p<=1);assert.ok(v2.summary[k].adjusted>=v2.summary[k].p);assert.ok(v2.evaluated.every(r=>r.pred[k].length===6&&new Set(r.pred[k]).size===6));}
for(const k of A.models){assert.ok(v2.scores[k].every(x=>x.score>=0&&x.score<=1));assert.ok(v2.summary[k].brier>=0&&v2.summary[k].brier<=1);}
const changed2=data.slice(0,100).map((d,i)=>i===99?{...d,n:E.randomTicket(E.rng(9))}:d);assert.deepEqual(A.run(prefix,1).evaluated[0].pred,A.run(changed2,1).evaluated[0].pred);assert.deepEqual(v2.evaluated.map(r=>r.pred.ai),all.evaluated.map(r=>({ai:r.ai})).map(x=>x.ai));
const p=A.patterns(data);assert.equal(p.ends.reduce((a,b)=>a+b,0),1251*6);assert.equal(p.low.reduce((a,b)=>a+b,0),1251);assert.equal(p.roll.reduce((a,b)=>a+b,0),1250);assert.ok(p.pairs[0].count>=p.pairs.at(-1).count);assert.equal(p.pairs[0].count,data.filter(r=>p.pairs[0].n.every(n=>r.n.includes(n))).length);
const g=A.generate({fixed:[3,17],exclude:[7,21,45],odd:3,min:100,max:160,count:20},E.rng(123));assert.equal(g.tickets.length,20);assert.equal(new Set(g.tickets.map(t=>t.join(','))).size,20);assert.ok(g.tickets.every(t=>t.includes(3)&&t.includes(17)&&![7,21,45].some(n=>t.includes(n))&&t.filter(n=>n%2).length===3&&t.reduce((a,b)=>a+b,0)>=100&&t.reduce((a,b)=>a+b,0)<=160));assert.throws(()=>A.generate({fixed:[1],exclude:[1]}));assert.throws(()=>A.generate({fixed:[1,2,3,4,5,6],min:100}));assert.equal(A.generate({fixed:[1,2,3,4,5,6],count:5}).tickets.length,1);assert.throws(()=>A.parseNums('1,1'));assert.throws(()=>A.parseNums('46'));assert.deepEqual(A.parseNums('3, 17 5'),[3,5,17]);
const rr={n:[1,2,3,4,5,6],bonus:7};assert.equal(A.result([1,2,3,4,5,6],rr),'1등');assert.equal(A.result([1,2,3,4,5,7],rr),'2등');assert.equal(A.result([1,2,3,4,5,8],rr),'3등');assert.equal(A.result([1,2,3,4,8,9],rr),'4등');assert.equal(A.result([1,2,3,8,9,10],rr),'5등');const sv={round:1252,n:[1,2,3,4,5,6],kind:'조건 조합'};assert.equal(A.validateSaved([sv,sv]).length,1);assert.throws(()=>A.validateSaved([{...sv,n:[1,2,3,4,5,45,46]}]));
console.log('PASS v2: 4 models, 6 baselines, chronological leakage tests, repeatability, confidence / p-value range, conditional generation, co-occurrence, saved ticket matching.');
const W=require('./weekly.js');
const w=W.run(data),wp=W.run(data.slice(0,1000)),wc=W.run(data.slice(0,1000).map((r,i)=>i===999?{...r,n:E.randomTicket(E.rng(991))}:r));
assert.equal(w.records.length,1201);assert.equal(w.adaptive.n,901);assert.equal(w.baseline.n,901);assert.equal(w.decision.window,300);assert.equal(w.next,1252);assert.equal(w.full.length,11);
assert.deepEqual(w.records.slice(0,950),wp.records);assert.deepEqual(wp.records.at(-1).pred,wc.records.at(-1).pred);assert.equal(wp.records.at(-1).winner,wc.records.at(-1).winner);assert.equal(wp.records.at(-1).selected,wc.records.at(-1).selected);
for(const k of [...W.candidates,'random'])assert.deepEqual(wp.pred[k],w.records[950].pred[k]);
assert.ok(w.records.every(r=>Object.values(r.pred).every(p=>p.length===6&&new Set(p).size===6&&p.every(n=>n>=1&&n<=45))));
assert.ok(Math.abs(W.upper(1,1)-W.P3)<1e-12);assert.equal(W.upper(20,0),1);assert.equal(W.upper(20,21),0);
const fake=Array.from({length:300},()=>({h:Object.fromEntries(W.candidates.map(k=>[k,0]))}));assert.equal(W.select(fake,Array(300).fill(0)).selected,'random');const strong=fake.map(r=>({h:{...r.h,ai:3}}));assert.equal(W.select(strong,Array(300).fill(3)).selected,'ai');
const now=Date.parse('2026-11-25T14:45:00+09:00');assert.equal(W.expectedNext(now),1252);assert.equal(W.expectedNext(Date.parse('2026-11-28T19:59:59+09:00')),1252);assert.equal(W.expectedNext(Date.parse('2026-11-28T20:00:00+09:00')),1253);
const l=W.append([],w,data,now);assert.equal(l.length,1);assert.deepEqual(W.append(l,w,data,now),l);assert.equal(W.append([],w,data,now+7*86400000).length,0);assert.deepEqual(W.validLog(JSON.parse(JSON.stringify(l))),l);
console.log('PASS v3: 11 fixed candidates, full walk-forward, nested trailing-window selection, leakage checks, exact null tail, guarded fallback, weekly cutoff and no duplicate/backfilled logs.');
