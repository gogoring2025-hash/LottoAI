/* LOTTO AI: fixed, auditable online logistic regression and chronological backtest. */
const Engine=(()=>{
'use strict';
const P=6/45, MIN=80, WARM=50, TRAIN=30, WINDOWS=[10,30,100];
const clip=(x,a,b)=>Math.max(a,Math.min(b,x));
const seq=()=>Array.from({length:45},(_,i)=>i+1);
function validate(input){
 if(!Array.isArray(input)||!input.length||input.length>10000)throw Error('데이터는 1~10,000회이어야 합니다.');
 const seen=new Set();
 const rows=input.map((d,i)=>{let r=Number(d.round), n=Array.isArray(d.n)?d.n.map(Number):[], b=d.bonus==null||d.bonus===''?null:Number(d.bonus);
 if(!Number.isSafeInteger(r)||r<1||seen.has(r)||n.length!==6||n.some(x=>!Number.isInteger(x)||x<1||x>45)||new Set(n).size!==6||(b!==null&&(!Number.isInteger(b)||b<1||b>45||n.includes(b))))throw Error(`${i+1}번째 행: 회차 또는 번호 범위·중복 오류`);
 seen.add(r);return {round:r,n:n.sort((a,b)=>a-b),bonus:b};});
 return rows.sort((a,b)=>a.round-b.round);
}
function parse(text){
 text=String(text).replace(/^\uFEFF/,'').trim();if(!text)throw Error('데이터가 비어 있습니다.');
 if(text.length>4000000)throw Error('파일이 너무 큽니다.');
 if(/^[\[{]/.test(text)){
 const j=JSON.parse(text), arr=Array.isArray(j)?j:(j.draws||j.data);if(!Array.isArray(arr))throw Error('지원하지 않는 JSON 형식입니다.');
 return validate(arr.map(d=>({round:d.round??d.draw??d.drawNo??d.draw_no,n:d.n??d.numbers,bonus:d.bonus??d.bonusNo??d.bonus_no})));}
 const lines=text.split(/\r?\n/).filter(l=>l.trim());const split=s=>s.trim().split(/[\t,; ]+/).map(x=>x.replace(/^"|"$/g,''));
 const head=split(lines[0]).map(x=>x.toLowerCase());const named=head[0]==='drwno'||head[0]==='회차'||head[0]==='round'||head[0]==='draw';
 const rows=lines.slice(named?1:0).map((line,i)=>{const x=split(line);let o=x[1]&&/^\d{4}-\d{2}-\d{2}$/.test(x[1])?2:1;
 if(x.length<o+6||(!named&&x.length>o+7))throw Error(`${i+1+(named?1:0)}번째 줄: 회차와 번호 6개, 선택 보너스를 입력하세요.`);
 return {round:x[0],n:x.slice(o,o+6),bonus:x[o+6]??null};});return validate(rows);
}
const csv=rows=>['round,n1,n2,n3,n4,n5,n6,bonus',...rows.map(r=>[r.round,...r.n,r.bonus??''].join(','))].join('\n');
const contiguous=rows=>rows.every((r,i)=>i===0||r.round===rows[i-1].round+1);
function verifyRemote(old,rows){if(rows[0].round!==1||!contiguous(rows)||rows.length<100||rows.some(r=>r.bonus===null))throw Error('전체 회차 데이터가 아니거나 누락되었습니다.');if(old.length&&rows.at(-1).round<old.at(-1).round)throw Error('서버 데이터가 현재 데이터보다 오래되었습니다.');const map=new Map(rows.map(r=>[r.round,r]));for(const a of old){const b=map.get(a.round);if(!b||a.n.join(',')!==b.n.join(',')||(a.bonus!==null&&a.bonus!==b.bonus))throw Error(`${a.round}회 기존 데이터와 불일치합니다. 공식 결과 확인 후 직접 가져오세요.`);}return rows;}
function stats(rows){const last=rows.at(-1), counts=Array(46).fill(0), lastSeen=Array(46).fill(-1), odd=Array(7).fill(0), sums=[],groups=Array(5).fill(0);let consecutive=0,repeatSum=0;
 rows.forEach((r,i)=>{let sum=0,o=0;for(const n of r.n){counts[n]++;lastSeen[n]=i;sum+=n;o+=n%2;groups[Math.min(4,Math.floor((n-1)/10))]++;}odd[o]++;sums.push(sum);if(r.n.some((n,j)=>j&&n===r.n[j-1]+1))consecutive++;if(i)repeatSum+=r.n.filter(n=>rows[i-1].n.includes(n)).length;});
 return {rows:rows.length,last,items:seq().map(n=>({n,count:counts[n],gap:rows.length-1-lastSeen[n],unseen:lastSeen[n]<0})),odd,groups,mean:sums.reduce((a,b)=>a+b,0)/rows.length,consecutive,repeat:rows.length>1&&contiguous(rows)?repeatSum/(rows.length-1):null};}
function rng(seed){let s=seed>>>0;return ()=>{s=(s+0x6D2B79F5)>>>0;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return ((t^(t>>>14))>>>0)/4294967296;};}
function randomTicket(rand=Math.random){let a=seq();for(let i=0;i<6;i++){const j=i+Math.floor(rand()*(45-i));[a[i],a[j]]=[a[j],a[i]];}return a.slice(0,6).sort((a,b)=>a-b);}
function rank(scores,round){const rand=rng((round^0x9e3779b9)>>>0);return seq().map(n=>({n,score:scores[n-1],tie:rand()})).sort((a,b)=>b.score-a.score||a.tie-b.tie);}
function sigmoid(x){return 1/(1+Math.exp(-clip(x,-30,30)));}
function create(){
 let w=[Math.log(P/(1-P)),0,0,0,0,0,0], history=[], counts=WINDOWS.map(()=>Array(46).fill(0)), total=Array(46).fill(0), last=Array(46).fill(-1);
 const z=(k,n)=>clip((k/n-P)/Math.sqrt(P*(1-P)/n),-3,3);
 function features(){let t=history.length;return seq().map(n=>[1,...WINDOWS.map((k,j)=>z(counts[j][n],Math.max(1,Math.min(k,t)))),clip((Math.min(t-1-last[n],24)-6.5)/7,-2,2),t>0&&last[n]===t-1?1-P:-P,z(total[n],Math.max(1,t))]);}
 function predict(x){return x.map(f=>sigmoid(f.reduce((s,v,j)=>s+v*w[j],0)));}
 function learn(x,y){const grad=w.map(()=>0),p=predict(x);for(let i=0;i<45;i++)for(let j=0;j<w.length;j++)grad[j]+=(p[i]-(y.includes(i+1)?1:0))*x[i][j]/45;
 for(let j=0;j<w.length;j++)w[j]-=0.08*(grad[j]+(j?0.025*w[j]:0));}
 function observe(row){let t=history.length;for(let j=0;j<WINDOWS.length;j++){if(t>=WINDOWS[j])for(const n of history[t-WINDOWS[j]].n)counts[j][n]--;for(const n of row.n)counts[j][n]++;}for(const n of row.n){total[n]++;last[n]=t;}history.push(row);}
 return {features,predict,learn,observe,frequency:()=>seq().map(n=>counts[1][n]),weights:()=>w.slice()};}
function check(rows){if(rows.length<MIN)throw Error(`머신러닝과 검증에는 연속 ${MIN}회 이상 필요합니다. 전체 데이터 갱신 또는 CSV 가져오기를 이용하세요.`);if(!contiguous(rows))throw Error('누락 회차가 있습니다. 연속된 회차 데이터로 다시 불러오세요.');}
function hit(ticket,row){return ticket.filter(n=>row.n.includes(n)).length;}
function choose(n,k){if(k<0||k>n)return 0;let a=1;for(let i=1;i<=k;i++)a=a*(n-i+1)/i;return a;}
const theory=Array.from({length:7},(_,k)=>choose(6,k)*choose(39,6-k)/choose(45,6));
function run(rows,limit=100){check(rows);let model=create(), start=Math.max(WARM,rows.length-limit), hist={ai:Array(7).fill(0),freq:Array(7).fill(0),random:Array(7).fill(0)}, evaluated=[],brier=0;
 for(let t=0;t<rows.length;t++){const r=rows[t],x=model.features();if(t>=start){const p=model.predict(x),ai=rank(p,r.round).slice(0,6).map(a=>a.n),freq=rank(model.frequency(),r.round).slice(0,6).map(a=>a.n),random=randomTicket(rng((r.round^0x25AC43B7)>>>0));const h={ai:hit(ai,r),freq:hit(freq,r),random:hit(random,r)};for(const key of Object.keys(hist))hist[key][h[key]]++;for(let j=0;j<45;j++)brier+=(p[j]-(r.n.includes(j+1)?1:0))**2/45; evaluated.push({round:r.round,h,ai:ai.sort((a,b)=>a-b),actual:r.n.slice()});}
 // Current outcome is not used until after all current-round scores are recorded.
 if(t>=TRAIN)model.learn(x,r.n);model.observe(r);}
 const count=evaluated.length,summary=Object.fromEntries(Object.entries(hist).map(([k,h])=>[k,{avg:h.reduce((s,n,i)=>s+n*i,0)/count,three:h.slice(3).reduce((a,b)=>a+b,0),max:h.reduce((s,n,i)=>n?i:s,0)}]));
 const next=rows.at(-1).round+1, scores=rank(model.predict(model.features()),next);return {count,start:evaluated[0].round,end:evaluated.at(-1).round,summary,hist,brier:brier/count,uniformBrier:P*(1-P),evaluated,scores,next,weights:model.weights(),theory};}
return {P,MIN,WARM,TRAIN,validate,parse,csv,contiguous,verifyRemote,stats,rng,randomTicket,run,theory,create,rank,check,hit,choose,sigmoid};})();
if(typeof module!=='undefined'&&module.exports)module.exports=Engine;
