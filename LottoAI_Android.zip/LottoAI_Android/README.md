# LOTTO AI · 개인용 안드로이드 v1.0

Android Studio용 소스 프로젝트입니다. APK는 포함되어 있지 않습니다. Android SDK와 Gradle이 없는 생성 환경에서 APK 컴파일/실기기 검증은 수행하지 못했습니다. 분석 엔진은 Node.js로 검증했고 브라우저 체험판과 같은 HTML을 앱에 포함합니다.

## 설치용 APK 만들기 (PC 필요)

1. https://developer.android.com/studio 에서 Android Studio를 설치합니다.
2. 이 ZIP을 압축 해제하고 Android Studio > Open에서 `LottoAI_Android` 폴더(최상위 `settings.gradle`이 있는 곳)를 선택합니다.
3. SDK Manager에서 Android SDK Platform 35를 설치하고, Gradle JDK를 17로 지정합니다. 프로젝트는 AGP 8.7.3 / Gradle 8.9 조합입니다. Gradle wrapper 바이너리는 포함하지 않았으므로, Android Studio에서 로컬 Gradle 8.9를 지정하거나 https://gradle.org/releases/ 에서 8.9를 설치한 후 프로젝트 폴더에서 `gradle wrapper --gradle-version 8.9`를 실행하고 다시 동기화합니다.
4. Build 메뉴에서 Generate App Bundles or APKs > Generate APKs (Studio 버전에 따라 Build APK(s))를 선택하거나 `gradlew.bat assembleDebug` (Windows) / `./gradlew assembleDebug` (macOS/Linux)를 실행합니다.
5. `app/build/outputs/apk/debug/app-debug.apk`를 휴대폰으로 전송하여 설치합니다. 필요 시 해당 파일을 연 앱의 '알 수 없는 앱 설치'를 잠시 허용합니다. APK를 설치한 뒤 허용을 해제할 수 있습니다.
6. Android 8.0(API 26) 이상, 최신 Android System WebView 권장. 이 버전은 개인용 디버그 APK이며 Play 스토어 출시를 전제로 하지 않습니다.

## 사용법

- 기본 데이터는 실제 1152~1251회 100회입니다. 인터넷 없이 즉시 AI와 백테스트를 실행할 수 있습니다. 초기 50회 준비 구간을 제외하므로 기본 자료에서는 50회 검증됩니다.
- 홈 → 전체 당첨번호 갱신: 공개 데이터 미러에서 전체 회차를 가져와 검증하고 로컬 저장합니다. 2026-11-25 확인 당시 1~1251회가 제공됩니다. 갱신 버튼은 수동 방식입니다.
- 외부 데이터 장애 시 https://cashlogy.kr/lotto/excel 에서 CSV를 받아 데이터 탭의 CSV/JSON 열기로 가져올 수 있습니다. 직접 가져오기는 기존 자료를 대체하므로 신뢰 가능한 자료만 사용하세요.
- AI 분석 → 모델 학습 및 분석. 백테스트 → 검증 기간을 선택하고 검증 실행.
- 브라우저 체험판은 `app/src/main/assets/index.html`입니다. 브라우저의 파일/네트워크 정책에 따라 데이터 자동 저장·갱신이 제한될 수 있습니다. CSV 직접 가져오기를 이용할 수 있습니다.

## 모델 및 검증

공통 로지스틱 회귀(번호별 45개 이진 분류), L2 정규화, 고정 학습률 0.08. 입력: 최근 10/30/100회 출현 빈도(표준화), 미출현 간격, 직전 회차 출현 여부, 누적 빈도. 첫 30회는 피처 준비, 첫 50회는 검증 제외. 이후 매 회차는 **이전 데이터로 먼저 점수를 기록하고 실제 추첨 결과를 본 뒤 학습**합니다. 전체 기간의 앞부분은 검증 시점 이전에 순차적으로 학습합니다. 비교 기준: 최근 30회 빈도 상위 6개 및 회차별 고정 시드의 균등 무작위 6개. 각 방식 회차당 1게임, 본번호 일치만 집계합니다. 브라이어 점수와 균등 기준도 표시합니다. 동점은 회차 기반 고정 난수로 해소합니다. 테스트 구간 성과로 모델 파라미터를 선택하는 자동 튜닝은 없습니다.

검증: `node tests/test.js` (가상 테스트 데이터로 파서, 데이터 검증, 일치 분포, 시간순 누출 방지 확인). 실제 100회 기본 데이터의 번호별 출현 횟수도 출처의 집계와 대조했습니다.

## 데이터 및 개인정보

- 기본 100회 당첨번호: 캐시로지 https://cashlogy.kr/lotto/recent/100 (동행복권 공개 결과 기반, CC BY 4.0, 출처 명시; 번호 및 보너스만 발췌하여 CSV로 변환). 라이선스: https://creativecommons.org/licenses/by/4.0/ . CSV 제공/재사용 정책: https://cashlogy.kr/lotto/excel .
- 전체 갱신: https://github.com/youngeun9100/project-l-data 및 https://raw.githubusercontent.com/youngeun9100/project-l-data/main/data/winning_numbers.json . 미러는 공식 서비스가 아니므로 정확한 결과는 https://www.dhlottery.co.kr/lt645/winNumber 에서 확인하세요.
- 갱신은 1회부터 연속인지, 본번호·보너스 범위/중복, 기존 자료 일치 여부 등을 점검합니다. 전체 데이터는 APK에 내장하지 않았습니다.
- 광고, 로그인, 추적 SDK, 구매/결제 없음. 분석은 로컬 JS 엔진, 저장은 WebView 로컬 저장소. 인터넷 권한은 사용자가 갱신을 눌렀을 때 공개 미러 조회에 사용합니다.
- 모든 번호 조합의 1등 이론 확률은 동일합니다. 모델 점수 및 과거 검증 결과는 미래 당첨 가능성의 개선을 보장하지 않습니다.
