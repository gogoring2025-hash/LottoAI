package com.lottoai.personal;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final String HISTORY = "https://raw.githubusercontent.com/youngeun9100/project-l-data/main/data/winning_numbers.json";
    private static final int FILE_REQUEST = 101;
    private WebView web;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean closed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !HOME.equals(req.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                if (HOME.equals(req.getUrl().toString()) && "GET".equals(req.getMethod())) {
                    try {
                        return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                    } catch (Exception ignored) { }
                }
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new LocalBridge(), "LottoNative");
        web.loadUrl(HOME);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != FILE_REQUEST || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri selected = data.getData();
        worker.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(selected)) {
                if (in == null) throw new Exception("empty stream");
                deliver("lottoImportResult", true, readText(in));
            } catch (Exception e) { deliver("lottoImportResult", false, "파일을 읽을 수 없습니다. UTF-8 CSV 또는 JSON을 확인하세요."); }
        });
    }
    private static String readText(InputStream in) throws Exception {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192]; int len;
        while ((len = in.read(chunk)) != -1) {
            if (buf.size() + len > 4000000) throw new Exception("data too large");
            buf.write(chunk, 0, len);
        }
        return new String(buf.toByteArray(), StandardCharsets.UTF_8);
    }
    public final class LocalBridge {
        @JavascriptInterface public void chooseData() {
            runOnUiThread(() -> {
                if (closed) return;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(i, FILE_REQUEST); }
                catch (Exception e) { deliver("lottoImportResult", false, "파일 선택기를 열 수 없습니다."); }
            });
        }
        @JavascriptInterface public void copyText(String text) {
            if (text == null || text.length() > 1000000) return;
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("LOTTO AI", text));
            });
        }
        @JavascriptInterface public void fetchHistory() {
            if (closed) return;
            worker.execute(() -> {
                HttpsURLConnection con = null;
                try {
                    con = (HttpsURLConnection) new URL(HISTORY).openConnection();
                    con.setInstanceFollowRedirects(false);
                    con.setConnectTimeout(10000);
                    con.setReadTimeout(15000);
                    con.setUseCaches(false);
                    con.setRequestProperty("Accept", "application/json, text/plain");
                    if (con.getResponseCode() != 200) throw new Exception("HTTP " + con.getResponseCode());
                    try (InputStream in = con.getInputStream()) {
                        deliver("lottoRemoteResult", true, readText(in));
                    }
                } catch (Exception e) {
                    deliver("lottoRemoteResult", false, "인터넷 연결 또는 데이터 서버 오류: " + e.getClass().getSimpleName());
                } finally { if (con != null) con.disconnect(); }
            });
        }
    }
    private void deliver(String callback, boolean ok, String payload) {
        runOnUiThread(() -> {
            if (closed || web == null) return;
            web.evaluateJavascript("window." + callback + "(" + ok + "," + JSONObject.quote(payload) + ");", null);
        });
    }
    @Override protected void onDestroy() {
        closed = true;
        worker.shutdownNow();
        if (web != null) { web.removeJavascriptInterface("LottoNative"); web.destroy(); web=null; }
        super.onDestroy();
    }
}
